//Abel Aguilar Chavez
//A01112847

public class Car{
	
	private String model;
	private int year;

	public void setModel(String model){
		this.model = model;
	}

	public String getModel(){
		return model;
	}

	public void setYear(int year){
		this.year = year;
	}

	public int getYear(){
		return year;
	}

	public Car(){
		System.out.println("Default Constructor");
		model = "Chevy";
		year = 2000;
	}

	public Car(String model, int year){
		this.model = model;
		this.year = year;
	}

	public void honk(){
		System.out.println("HONK");
	}

	public void breaks(){
		System.out.println("Breaks engaged");
	}


}
//Abel Aguilar Chavez
//A01112847

public class Kangaroo{

	private String name;
	private int age;

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setAge(int age){
		this.age = age;
	}

	public int getAge(){
		return age;
	}


	public Kangaroo(){
		System.out.println("Default constructor");
		name = "Charlie";
		age = 2;
	}

	public Kangaroo(String name, int age){
		this.name = name;
		this.age = age;
	}

	public void jump(){
		System.out.println("Jumping");
	}

	public void fight(){
		System.out.println("Fighting");
	}

}
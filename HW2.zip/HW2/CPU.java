//Abel Aguilar Chavez
//A01112847

public class CPU{
	private String memory;
	private String clk_speed;


	public void setMemory(String memory){
		this.memory = memory;
	}

	public String getMemory(){
		return memory;
	}

	public void setClk_Speed(String clk_speed){
		this.clk_speed = clk_speed;
	}

	public String getClk_Speed(){
		return clk_speed;
	}


	public CPU(){
		System.out.println("Default constructor");
		memory = "500 Gb";
		clk_speed = "2.5GHz";
	}

	public CPU(String memory, String clk_speed){
		this.memory = memory;
		this.clk_speed = clk_speed;
	}

	public void boot(){
		System.out.println("Booted");
	}

	public void compile(){
		System.out.println("Compiled");
	}



}
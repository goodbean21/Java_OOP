//Abel Aguilar Chavez
//A01112847

public class HW2{
	
	public static void main(String[] args){

		// Cars:
		System.out.println("Cars:");

		Car Def;
		Def = new Car();
		Car Kia = new Car("Kia Rio", 2018);
		
		System.out.println(Def.getModel());
		System.out.println(Def.getYear());
		System.out.println(Kia.getModel());
		System.out.println(Kia.getYear());

		Def.honk();
		Kia.breaks();

		// Kangaroos:
		System.out.println("Kangaroos:");

		Kangaroo DefK;
		DefK= new Kangaroo();
		Kangaroo baby = new Kangaroo("Liz", 1);

		System.out.println(DefK.getName());
		System.out.println(DefK.getAge());
		System.out.println(baby.getName());
		System.out.println(baby.getAge());

		baby.jump();
		System.out.println("Stranger appears");
		DefK.fight();

		// CPU:
		System.out.println("CPU:");

		CPU DefC;
		DefC = new CPU();
		CPU Dell_Inspiron = new CPU("2 TB", "3.5 GHz");

		System.out.println(DefC.getMemory());
		System.out.println(DefC.getClk_Speed());
		System.out.println(Dell_Inspiron.getMemory());
		System.out.println(Dell_Inspiron.getClk_Speed());

		Dell_Inspiron.boot();
		Dell_Inspiron.compile();

	} 
}
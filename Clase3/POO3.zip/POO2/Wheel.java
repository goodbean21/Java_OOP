public class Wheel {

  // attributes
  private float size;
  private String brand;

}

public class Head{
	private Eye L_eye;
	private Eye R_eye;
	private String eye;

	public void setL_Eye(Eye L_eye){
		this.L_eye = L_eye;
	}

	public void setR_Eye(Eye R_eye){
		this.R_eye = R_eye;
	}

	public Eye getEye(String eye){
		if(eye == "Left"){
			return L_eye;
		}else if (eye == "Right"){
			return R_eye;
		}else{
			return null;
		}
	}

	public Head(){
		L_eye = new Eye();
		R_eye = new Eye();
	}	

}


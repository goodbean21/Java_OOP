public class Dog2{
	
	private float strength; 
	private float speed;
	private String name;
	private	Head head;
	private float Strength;
	private float Speed;
	private String Name;

	public float getStrength(){
		return strength;
	}

	public float getSpeed(){
		return speed;
	}

	public String getName(){
		return name;
	}

	public Head getHead(){
		return head;
	}

	public Dog2(){	
		head = new Head();
		strength = 34f;
		speed = 3.2f;
		name= "Fido";
	}

	public Dog2(float strength, float speed, String name){
		this.strength = strength;
		this.speed = speed;
		this.name = name;
		this.head = new Head();

	}

	public void fight(float Strengt, String Name){


		if (Strength > strength){
			System.out.println("Ganó " + (Name));

		}else if (strength > Strength){
			System.out.println("Ganó " + (name));

		}else{
			System.out.println("Fue un empate");
		}

	}

	public void race(float Speed, String Name){
		if (Speed > speed){
			System.out.println("Ganó " +Name);

		}else if (speed > Speed){
			System.out.println("Ganó " + name);

		}else{
			System.out.println("Fue un empate");
		}
	}

}

public class Eye{
	
	public Eye(){
		System.out.println("Default Constructor");
	}

	public void Blink(){
		System.out.println("*blink*");
	}
}
public class Dog{
	
	private float[] strength; 
	private float[] speed;
	private String[] name;
	private	Head head;

	public float getStrength(){
		for (int i = 0; i < strength.length; i++){
			System.out.println(strength[i]);
		}
		return 0;
	}

	public float getSpeed(){
		for (int i = 0; i < speed.length; i++){
			System.out.println(speed[i]);
		}

		return 0;
	}

	public String getName(){
		for (int i = 0; i < name.length; i++){
			System.out.println(name[i]);
		}
		return null;
	}

	public Dog(){	
		head = new Head();
		strength = new float[2];
		speed = new float[2];
		name = new String[2];

		strength[0] = 34f;
		speed[0] = 3.2f;
		name[0] = "Fido";
	}

	public Dog(float strength, float speed, String name, int i){
		this.strength = new float[2];
		this.speed = new float[2];
		this.name = new String[2];

		this.strength[i] = strength;
		this.speed[i] = speed;
		this.name[i] = name;
		this.head = new Head();

	}

	public fight(){

		if (strength[0] > strength[1]){
			System.out.println("Ganó " + (name[0]));

		}else if (strength[1] > strength[0]){
			System.out.println("Ganó " + (name[1]));

		}else{
			System.out.println("Fue un empate");
		}

	}

	public void race(){
		if (speed[0] > speed[1]){
			System.out.println("Ganó " +name[0]);

		}else if (speed[1] > speed[0]){
			System.out.println("Ganó " + name[1]);

		}else{
			System.out.println("Fue un empate");
		}
	}

}
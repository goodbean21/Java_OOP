public class main{

	public static void main(String[] args){


		Dog2 Ellie = new Dog2(44f,2.3f,"Ellie");
		Dog2 Fido = new Dog2(32f, 2.5f, "Fido");
		System.out.println(Ellie.getStrength());
		System.out.println(Fido.getStrength());
		Ellie.fight(Fido.getStrength(),Fido.getName());
		Ellie.race(Fido.getSpeed(),Fido.getName());
		Ellie.getHead().getEye("Left").Blink();
		Ellie.getHead().getEye("Right").Blink();


	}

	
}
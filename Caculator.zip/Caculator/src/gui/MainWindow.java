package gui;

import java.awt.*;
import javax.swing.*;

public class MainWindow extends JFrame{
	
	public MainWindow() {

		super("Calculator");
		CalcPanel Calc = new CalcPanel();
		JTextField tField = Calc.tField;
		
		tField.setFont(new Font("Arial", 20, 80));
		tField.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		
		
		BorderLayout B = new BorderLayout();
		setLayout(B);
		
		add(tField, BorderLayout.NORTH);

		add(Calc, BorderLayout.CENTER);		
		setSize(400, 600);
		setLocation(500, 500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		while(true) tField.setText(Calc.getcurrentS());

		
	}
	
}
package gui;

import java.awt.*;
import java.awt.event.*;
import java.util.function.BiFunction;
import javax.swing.*;

public class CalcPanel extends JPanel implements ActionListener{
	
	String currentS, lastop;
	double a = 0, b = 0, S = 0, x = 0, Last = 0;
	
	JTextField tField = new JTextField();
	
	final JButton[] Bnum = new JButton[20];
	final String[] names = {
			"CE","C","Bck", "/",
			"7", "8", "9", "X", 
			"4", "5", "6", "-", 
			"1", "2", "3", "+", 
			"+/-", "0", ".", "="};
		
	public String getcurrentS() {
		return currentS;
		
	}
	
	private static Double Operation(Double x, Double y, BiFunction<Double, Double, Double> consumer) {
		return consumer.apply(x, y);
		 
	}
	private static String reverseSubstring(String text, int startIndex, int endIndex) {
	    String result = text.substring(0,startIndex); //before reversing
	    result += new StringBuilder(text.substring(startIndex,endIndex)).reverse().toString(); //reversed part
	    result += text.substring(endIndex); //after reversing
	    return result;
	    
	}
	
	public CalcPanel() {
		
		final GridLayout g = new GridLayout(5, 4);
		currentS = "0";

		setLayout(g);

		for(int i = 0; i < Bnum.length; i++) {
			Bnum[i] = new JButton(names[i]);
			
		}
		
		for (int i = 0; i < Bnum.length; i++){
			add(Bnum[i]);
			Bnum[i].addActionListener(this);
		}
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		String s = e.getActionCommand();
	
		switch(s) {
			case "+":
				if(lastop != "=") x = Operation(a, b, (a, b) -> a + b);
				a = x;
				currentS = "0";
				b = 0;
				lastop = s;
				
				break;
				
			case "X":
				 if(lastop != "=") 	 x = Operation(a, b, (a, b)-> a * b);
				 a = x;
				 currentS = "0";
				 b = 0;
				 lastop = s;
				 
				 break;
				
			case "/":
				
				if(lastop != "=") x = Operation(a, b, (a, b)-> a / b);
				a = x;
				currentS = "0";
				b = 0;
				lastop = s;
	
				break;
				
			case "-":
				 if(lastop != "=") x = Operation(a, b, (a, b)-> a - b);
				 a = x;
				 b = 0;
				 currentS = "0";
				 lastop = s;
	
				 break;
			
			case "=":
				
				switch (lastop) {
					case "+":
						x = Operation(a, b, (a, b) -> a + b);
						
						break;
						
					case "-":
						 x = Operation(a, b, (a, b) -> a - b);
						 
						break;
						
					case "X":
						 x = Operation(a, b, (a, b) -> a * b);
						
						break;
						
					case "/":
						 x = Operation(a, b, (a, b)-> a / b);
						
						break;
				}
				
				a = x;
				b = 0;
				lastop = "=";
				
				if(Double.isInfinite(x)) {
					currentS = "DNE";
					break;
					
				}
				
				currentS = Double.toString(x);
				
				if(currentS.startsWith("-")) {
					String[] STR = currentS.split("-");
					currentS = STR[1] + "-";
					
				}
				
				if(currentS.length() > 10) {
					String Str = reverseSubstring(currentS, 0, currentS.length());
					Str = Str.substring(currentS.length() - 10, currentS.length());
					Str = reverseSubstring(Str, 0, Str.length());
					currentS = Str;
					
				}
				
				Last = x;
				
				break;
				
			case "CE":
				a = Last;
				b = 0;
				x = 0;
				currentS = Double.toString(a);
				
				break;
				
			case "C":
				currentS = "0";
				a = 0;
				b = 0;
				x = 0;
				break;
			
			case "Bck":				
				boolean add = false;
				
				if(currentS != "0" && !currentS.isEmpty()) {
					if(currentS.contains("-")) {
						String[] STR = currentS.split("-");
						currentS =  STR[0];
						add = true;
						
					}
					
					String Str = reverseSubstring(currentS, 0, currentS.length());
					Str = Str.substring(1, currentS.length());
					Str = reverseSubstring(Str, 0, Str.length());
					
					currentS = Str;
					
					if(currentS.isEmpty() || currentS == "-") {
						currentS = "0";
						
					}
					
					if(add && currentS != "0") {
						currentS = currentS + "-";
						add = false;
						
					}
					
					if(currentS.endsWith(".")) {
						currentS= currentS.replace('.', ' ');
						currentS = currentS.substring(0,1);

					}else if(currentS.endsWith(".-")) {
						String[] STR  = currentS.split("-");
						currentS = STR[0];
						currentS= currentS.replace('.', '-');
						
					}
										
				}
				
				break;
				
			case "+/-":
				if(!currentS.contains("-") && currentS != "0") {
					S = Double.parseDouble("-" + currentS);
					currentS = currentS + "-";

				}else {	
					String[] STR = currentS.split("-");
					currentS = STR[0];
					S = Double.parseDouble(currentS);
	
				}
				
				break;
				
			case ".":
				if(!currentS.contains(".")) {
					currentS = currentS + ".";
					
				}
				
				break;
				
			default:		
				if(currentS.endsWith("0") && currentS.startsWith("0")) {
					currentS = s;
					
				}else {
					currentS = currentS + s;
					
				}
				if(currentS.contains("-")) {
					String[] STR = currentS.split("-");
					currentS =  STR[0] + STR[1] + "-" ;
					
				}
				
				try {	
					S = Double.parseDouble(currentS);
				}catch(Exception e1){
					 e1.getMessage();
					 
				}
				
				break;
				
		}
	
		if (a == 0 && (s == "+" || s == "X" || s == "-" || s == "/")) {
			a = S;
			
		}if(a != 0) {
			b = S;
			
		}
		
	}
	
}
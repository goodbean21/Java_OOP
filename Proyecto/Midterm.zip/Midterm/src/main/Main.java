package main;
/*
 * Proyecto de Programaci�n orientada a objetos
 * 
 * Equipo: 
 * Abel Aguilar Ch�vez A01112847
 * Nadia Paulina Gonz�lez Dom�nguez A01186895
 * 
 */

import gui.MainWindow;

public class Main {

	public static void main(String[] args) {
		new MainWindow();
		
	}

}
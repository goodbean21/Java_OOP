public class Vehicle{

	protected String medium;
	protected float speed;

	public String getMedium(){
		return medium;
	}
	public void setMedium(String medium){
		this.medium = medium;
	}

	public float getSpeed(){
		return speed;
	}

	public void setSpeed(float speed){
		this.speed = speed;
	}

	public Vehicle(){
		System.out.println("Default Constructor");
		medium = "Land";
		speed = 120f;
	}
	public Vehicle(String medium, float speed){
		this.medium = medium;
		this.speed = speed;
	}

	public void Move(){
		System.out.println("Moving");
	}
}
public class SportsCar extends Car{
	protected String brand;
	protected int emisionC02;

	public String getBrand(){
		return brand;
	}

	public int getEmissionCO2(){
		return emisionC02;
	}

	public void setBrand(String brand){
		this.brand = brand;
	}

	public void setEmissionCO2(int emisionC02){
		this.emisionC02 = emisionC02;
	}

	public SportsCar(){
		super("Land",250f, 8.2f, 2018);
		brand = "Mercedes";
		emisionC02 = 280;	
	}
	public SportsCar(String medium, float speed, float gasConsum, int year, String brand, int emisionC02){
		super(medium, speed, gasConsum, year);
		this.brand = brand;
		this.emisionC02 = emisionC02;
	}

	public void Zoom(){
		System.out.println("Zoom Zoom");
	}

}
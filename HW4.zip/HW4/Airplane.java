public class Airplane extends Vehicle{
	protected String airline;
	protected int cap;

	public int getCap(){
		return cap;
	}

	public void setCap(int cap){
		this.cap = cap;
	}

	public String getAirline(){
		return airline;
	}

	public void setAirline(String airline){
		this.airline = airline;
	}

	public Airplane(){
		super("Airborne", 800f);
		this.cap = 615;
		this.airline = "Aeromexico";
	}

	public Airplane(String medium, float speed,int cap, String airline){
		super(medium, speed);
		this.cap = cap;
		this.airline = airline;

	}
	public void Fly(){
		System.out.println("Soaring through the skyy");
	}
}
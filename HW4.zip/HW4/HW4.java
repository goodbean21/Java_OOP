public class HW4{
	public static void main(String[] args){

		System.out.println("Train:");
		Vehicle train = new Vehicle();

		System.out.println("Before setting");
		System.out.println(train.getSpeed());
		System.out.println(train.getMedium());

		System.out.println("After setting");
		train.setSpeed(122f);
		train.setMedium("Anfibio");
		System.out.println(train.getSpeed());
		System.out.println(train.getMedium());

		train.Move();

		System.out.println("\nJumbo airplane:");
		Airplane jumbo = new Airplane();

		System.out.println("Before setting");
		System.out.println(jumbo.getSpeed());
		System.out.println(jumbo.getMedium());
		System.out.println(jumbo.getCap());
		System.out.println(jumbo.getAirline());

		System.out.println("After setting");
		jumbo.setSpeed(700);
		jumbo.setMedium("Anfibio");
		jumbo.setCap(700);
		jumbo.setAirline("Volaris");
		System.out.println(jumbo.getSpeed());
		System.out.println(jumbo.getMedium());
		System.out.println(jumbo.getCap());
		System.out.println(jumbo.getAirline());

		jumbo.Move();
		jumbo.Fly();

		System.out.println("\nCamioneta:");
		Car cam = new Car();

		System.out.println("Before setting");
		System.out.println(cam.getGasConsum());
		System.out.println(cam.getYear());
		System.out.println(cam.getSpeed());
		System.out.println(cam.getMedium());
	
		System.out.println("After setting");
		cam.setMedium("Anfibio");
		cam.setSpeed(100f);
		cam.setGasConsum(8.8f);
		cam.setYear(2014);
		System.out.println(cam.getGasConsum());
		System.out.println(cam.getYear());
		System.out.println(cam.getSpeed());
		System.out.println(cam.getMedium());

		cam.Move();
		cam.Engine();

		System.out.println("\nSportsCar:");
		SportsCar cool = new SportsCar();

		System.out.println("Before setting");
		System.out.println(cool.getBrand());
		System.out.println(cool.getEmissionCO2());
		System.out.println(cool.getGasConsum());
		System.out.println(cool.getYear());
		System.out.println(cool.getSpeed());
		System.out.println(cool.getMedium());	
	
		System.out.println("After setting");
		cool.setBrand("BMW");
		cool.setEmissionCO2(49);
		cam.setMedium("Land");
		cam.setSpeed(250f);
		cam.setGasConsum(6.7f);
		cam.setYear(2016);
		System.out.println(cool.getBrand());
		System.out.println(cool.getEmissionCO2());
		System.out.println(cool.getGasConsum());
		System.out.println(cool.getYear());
		System.out.println(cool.getSpeed());
		System.out.println(cool.getMedium());

		cool.Move();
		cool.Engine();
		cool.Zoom();

	}	
}
public class Car extends Vehicle{
	protected float gasConsum;
	protected int year;

	public float getGasConsum(){
		return gasConsum;
	}

	public void setGasConsum(float gasConsum){
		this.gasConsum = gasConsum;
	}

	public int getYear(){
		return year;
	}

	public void setYear(int year){
		this.year = year;
	}

	public Car(){
		super();
		this.gasConsum = 9.56f;
		this.year = 2016;

		
	}
	public Car(String medium, float speed, float gasConsum, int year){
		super(medium, speed);
		this.year = year;
		this.gasConsum = gasConsum;
	}

	public void Engine(){
		System.out.println("Vroom Vroom");
	}
}
public class OlympicCompetition {
	
	public static String trackEvent(Human h1, Human h2) {
		if(h1.getSpeed() > h2.getSpeed())
			return "The fastest is " + h1.getName() + 
					" with a speed of " + h1.getSpeed();
		
		return "The fastest is " + h2.getName() + 
				" with a speed of " + h2.getSpeed();
					
	}
	
}

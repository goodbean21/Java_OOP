
public class Main {

	public static void main(String[] args) {
		float acc = 1.4f;
		
		Human h1 = new Human();
		Human h2 = new Human("Luis", 35.5f, 3.4f);

		Runner r1 = new Runner();
		Runner r2 = new Runner("Mar�a", 40.5f, 4.7f, 2);
		
		// Print all properties
		System.out.println(h1.getName());
		System.out.println(h1.getSpeed());
		System.out.println(h1.getStrength());
		
		System.out.println(h2.getName());
		System.out.println(h2.getSpeed());
		System.out.println(h2.getStrength());		
		
		System.out.println(r1.getName());
		System.out.println(r1.getSpeed());
		System.out.println(r1.getStrength());
		System.out.println(r1.getNumberOfMedals());
		
		System.out.println(r2.getName());
		System.out.println(r2.getSpeed());
		System.out.println(r2.getStrength());
		System.out.println(r2.getNumberOfMedals());

		// Invoke all methods
		System.out.println(h2.run());
		System.out.println(h2.run(acc));
		System.out.println(h2.run(r2));
		
		System.out.println(r2.run());
		System.out.println(r2.run(acc));
		System.out.println(r2.run(h2));
		
		// Invoke TrackEvent method
		System.out.println(OlympicCompetition.trackEvent(h2, r2));
		
	}

}

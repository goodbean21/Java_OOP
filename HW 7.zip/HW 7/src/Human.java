
public class Human {
	private float speed;
	private float strength;
	private String name;
	
	
	
	public float getSpeed() {
		return speed;
		
	}

	public void setSpeed(float speed) {
		this.speed = speed;
		
	}

	public float getStrength() {
		return strength;
		
	}

	public void setStrength(float strength) {
		this.strength = strength;
		
	}

	public String getName() {
		return name;
		
	}

	public void setName(String name) {
		this.name = name;
		
	}
	
	public Human() {
		this.name = null;
		this.strength = 0;
		this.speed = 0;
		
	}
	
	public Human(String name, float strength, float speed) {
		this.name = name;
		this.strength = strength;
		this.speed = speed;
		
	}
	
	public String run() {
		return " GOTTA GO FAST";
	
	}
	
	public float run(float acc) {
		this.speed = this.speed*acc;
		return speed;

	}
	
	public String run(Human otherHuman) {
		String msg =  "On your right, " + otherHuman.getName();
		return msg;
	
	}
}


public class Runner extends Human{
	
	private int numberOfMedals;
	
	public int getNumberOfMedals() {
		return numberOfMedals;
	
	}

	public void setNumberOfMedals(int numberOfMedals) {
		this.numberOfMedals = numberOfMedals;
	
	}

	public Runner() {
		super();
		this.numberOfMedals = 0;
		
	}

	public Runner(String name, float strength, float speed, int numberOfMedals) {
		super(name, strength, speed);
		this.numberOfMedals = numberOfMedals;

	}
	
	public String run() {
		return "GOTTA GO EVEN FASTER";
		
	}
	

}

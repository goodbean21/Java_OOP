package main;

import hanoiTower.HanoiTower;

public class Main {

	public static void main(String[] args) {
		HanoiTower.solver(3, "A", "B", "C");
		
	}

}
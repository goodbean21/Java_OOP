package hanoiTower;

public class HanoiTower {

	public static void solver(int n, String source, String aux, String dest){
		// If only 1 disk, make the move and return.
		if(n==1) System.out.println(source+" --> "+dest);
		else {
			solver(n-1, source, dest, aux);
			
			System.out.println(source+" --> "+dest);
			
			solver(n-1, aux, source, dest);
			
		}	
	}
}

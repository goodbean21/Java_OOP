// Abel Aguilar Chavez
// A01112847

public class Movie{
	
	private String title;
	private int year;
	private float rating;


	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return title;
	}

	public void setYear(int year){
		this.year = year;
	}

	public int getYear(){
		return year;
	}

	public void setRating(float rating){
		this.rating = rating;
	}

	public float getRating(){
		return rating;
	}


	public Movie(){
		title = "The Iron Giant";
		year = 1999;
		rating = 8.5f;
	}

	public Movie(String title, int year, float rating){
		this.title = title;
		this.year = year;
		this.rating = rating;
	}

	public void movieAndChill(){
		System.out.println("The original 1988 version was better");
	}
}
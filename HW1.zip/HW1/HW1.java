// Abel Aguilar Chavez
// A01112847

public class HW1 {
	
	public static void main(String[] args){

		Instruments guitar;

		guitar = new Instruments();

		//price, name, type
		Instruments piano = new Instruments(15499.99f, "Piano", "Electric");


		guitar.readyToRamble();


		Console Nintendo;

		Nintendo = new Console();

		//  brand,  name,  price
		Console Sony = new Console("Sony", "Playstation 4", 8999.99f);

		System.out.println(Nintendo.getName());
		System.out.println(Nintendo.getBrand());
		System.out.println(Nintendo.getPrice());


		Movie Iron_Giant;

		Iron_Giant = new Movie();

		//String title, int year, float rating
		Movie couldGoFor = new Movie("Babel", 2006, 7.5f);

		couldGoFor.movieAndChill();

		System.out.println(couldGoFor.getTitle());
		System.out.println(couldGoFor.getYear());
		System.out.println(couldGoFor.getRating());
	}
}


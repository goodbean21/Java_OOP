// Abel Aguilar Chavez
// A01112847

public class Console{
	private String brand;
	private String name;
	private float price;


	public void setBrand(String brand){
		this.brand = brand;
	}

	public String getBrand(){
		return brand;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setPrice(float price){
		this.price = price;
	}

	public float getPrice(){
		return price;
	}

	public Console(){
		brand = "Nintendo";
		name = "Switch";
		price = 8999.99f;
	}

	public Console(String brand, String name, float price){
		this.brand = brand;
		this.name = name;
		this.price = price;
	}

	public void timeToPlay(){
		System.out.println("The frame rate is awful, but the game is ok.");
	}
}
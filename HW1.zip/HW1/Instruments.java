// Abel Aguilar Chavez
// A01112847

public class Instruments{
	
	//Atributes

	private String name;
	private	String type;
	private	float price;

/* accessor methods
	- set / get
*/

// PRICES
	public void setPrice(float price){
		this.price = price;

	}

	public float getPrice(){
		return price;

	} 

// NAMES
	public void setName(String name){
		this.name = name;

	}

	public String getName(){
		return name;

	}

// TYPE
	public void setType(String type){
		this.type = type;

	}

	public String getType(){
		return type;

	}


// DEFAULT CONSTRUCTOR -- NO PARAMETERS GIVEN

	public Instruments(){
		price = 7999.99f;
		name = "Guitar";
		type = "Electric";
	}

// IF PARAMETERS ARE GIVEN

	public Instruments(float price, String name, String type){
		this.price = price;
		this.type = type;
		this.name = name;
	}

	public void readyToRamble(){
		System.out.println("You are ready to rambleee!");
	}

}
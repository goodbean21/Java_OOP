package Office;

import Delivers.Robot;
import Interfaces.Transporter;

public class MailOffice{
	
	public static String getFastestDelivery(Transporter T1, Transporter T2) {
		if(T1.calculateSpeed()>T2.calculateSpeed()) {
			return T1.stateYourName() + " is the fastest";
			
		}
		
		return T2.stateYourName() + " is the fastest";
	
	}
	
	public static String getNewerRobot(Robot R1, Robot R2) {
		if(R1.getYear() > R2.getYear()) {
			return R1.getName() + " is the newest";
			
		}
		
		return R2.getName() + " is the newest";
	
	}

}

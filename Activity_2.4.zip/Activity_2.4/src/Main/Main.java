package Main;

import Delivers.*;
import Office.MailOffice;

public class Main {

	public static void main(String[] args) {
		
		Robot R1 = new Robot("Mitsubishi", "O-Z", 2008);
		DeliveryPlane Plane = new DeliveryPlane("Aeromexico", 2011, 455.2f);
		DeliveryRobot DR1 = new DeliveryRobot("Nissan", "Lilo", 2012, 55.3f);
		Mailman M1 = new Mailman("Carlos");
		
		System.out.println(MailOffice.getFastestDelivery(DR1, M1));
		System.out.println(MailOffice.getFastestDelivery(Plane, M1));
		System.out.println(MailOffice.getFastestDelivery(DR1, Plane));
		
		System.out.println(MailOffice.getNewerRobot(R1, DR1));
		
	}

}
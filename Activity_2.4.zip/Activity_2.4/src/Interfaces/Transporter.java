package Interfaces;

public interface Transporter {
	
	public float calculateSpeed();
	public String stateYourName();

}

package Delivers;

import Interfaces.Transporter;

public class Mailman implements Transporter{
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Mailman(String name) {
		super();
		this.name = name;
	
	}
	
	public void Deliver() {
		System.out.println("Delivering");
		
	}

	@Override
	public float calculateSpeed() {
		return 5;
		
	}

	@Override
	public String stateYourName() {
		return name;
		
	}

}

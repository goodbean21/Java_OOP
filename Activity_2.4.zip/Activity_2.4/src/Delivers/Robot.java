package Delivers;

public class Robot {
	
	protected String model, name;
	protected int year;
	
	public String getModel() {
		return model;
	}
	
	public void setModel(String model) {
		this.model = model;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getYear() {
		return year;
	}
	
	public void setYear(int year) {
		this.year = year;
	}
	
	public Robot(String model, String name, int year) {
		super();
		this.model = model;
		this.name = name;
		this.year = year;
	}

	
}

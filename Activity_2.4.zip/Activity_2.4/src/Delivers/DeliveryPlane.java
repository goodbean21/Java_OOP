package Delivers;

import Interfaces.Transporter;

public class DeliveryPlane implements Transporter{
	
	private String model;
	private int year;
	private float max_Speed;
	
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public float getMax_Speed() {
		return max_Speed;
	}
	public void setMax_Speed(float max_Speed) {
		this.max_Speed = max_Speed;
	}
	
	public DeliveryPlane(String model, int year, float max_Speed) {
		super();
		this.model = model;
		this.year = year;
		this.max_Speed = max_Speed;
	}
	
	@Override
	public float calculateSpeed() {
		return max_Speed*0.8f;
	}

	@Override
	public String stateYourName() {
		return model;
	}

}


public class ArrayList<E> {
	
	private E[] Data;
	private int currentPosition;
	
	public ArrayList() {
		Data = (E[]) new Object[1];
		currentPosition = 0;
		
	}
	
	public void add(E newValue) {
		if(Data.length == currentPosition) {
			E[] temp = (E[]) new Object[Data.length * 2];
			
			for(int i = 0; i < currentPosition; i++) temp[i] = Data[i];
						
			Data = temp;
		
		}
		
		Data[currentPosition] = newValue;
		currentPosition++;
		
	}
	
	public void delete(int index) {
		for(int i = index; i < currentPosition - 1; i++) Data[i] = Data[i + 1];
		currentPosition--;
		
		if(currentPosition < (Data.length/2)) {
			E[] temp = (E[]) new Object[Data.length/2];
			
			for(int i = 0; i < currentPosition; i++) temp[i] = Data[i];
			
			Data = temp;
		
		}
		
	}
	
	public E get(int index) {
		return Data[index];
		
	}
	
	public int size() {
		return currentPosition;
		
	}
	
	public String toString() {
		String result = "";
		for(int i = 0; i < currentPosition; i++) result += Data[i] + " \n";	
		return result;
	
	}
	
}
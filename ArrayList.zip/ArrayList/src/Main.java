public class Main {

	public static void main(String[] args) {
		ArrayList<String> names = new ArrayList<>();
		
		names.add("Luis");
		names.add("Maria");
		names.add("Pedro");
		names.add("RIP");
		
		System.out.println(names);
		System.out.println(names.size());
		
		names.delete(1);
		
		System.out.println(names);
		System.out.println(names.size());
		
		System.out.println(names.get(2));
	
	}
	
}
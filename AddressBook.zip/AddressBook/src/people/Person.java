package people;

public class Person {
	
	private String Name, address, tlp;
	
	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTlp() {
		return tlp;
	}

	public void setTlp(String tlp) {
		this.tlp = tlp;
	}
	
	public Person() {
		Name = "<Name>";
		address = "<Address>";
		tlp = "<Telephone>";
	
	}

	public Person(String name, String address, String tlp) {
		Name = name;
		this.address = address;
		this.tlp = tlp;
		
	}

}

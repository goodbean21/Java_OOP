package gui;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;

import javax.swing.*;

import people.Person;

public class DownBtns extends JPanel implements ActionListener{
	
	protected static ArrayList<Person> people = new ArrayList<Person>(); 
	
	protected JButton[] btn2 = new JButton[6];
	private String[] btn2Name = {
			"Load records", "Save records", "Add records", 
			"Next record", "Previous records", "Sort Record"
			};
	
	protected CentralPanel myCentral;
	protected LeftBtns myLeftBtns;
	
	protected MainWindow myMainWindow;

	protected String[] data, values;
	
	public static List<Person> getPeople() {
		return people;
		
	}
	
	public void setMyLeftBtns(LeftBtns myLeftBtns) {
		this.myLeftBtns = myLeftBtns;
	}

	public void setMyMainWindow(MainWindow myMainWindow) {
		this.myMainWindow = myMainWindow;
	}

	public void setMyCentral(CentralPanel myCentral) {
		this.myCentral = myCentral;
	}

	interface Condition{
		boolean test(Person p);
		
	}
	
	public DownBtns() {
		people.add(new Person());
		
		GridLayout g = new GridLayout(1, 6);
		setLayout(g);
		
		for(int i = 0; i < btn2.length; i++) {
			btn2[i] = new JButton(btn2Name[i]);
			btn2[i].addActionListener(this);
			add(btn2[i]);
			
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String s = e.getActionCommand();
		
		switch (s) {
		case "Load records":	

			JFileChooser fc = new JFileChooser("C:\\Users\\Usuario\\Desktop\\");
			int returnVal = fc.showOpenDialog(myMainWindow);		
			
			if(returnVal == JFileChooser.APPROVE_OPTION) {
				myCentral.Text.setText("");
				FileReader f;
				BufferedReader br = null;
				
				try {
					f = new FileReader(fc.getSelectedFile());
					br = new BufferedReader(f);
					
					Scanner inputStream = new Scanner(fc.getSelectedFile());
					int j = 0;
					
					while(inputStream.hasNext()) {
						String data = inputStream.next();
						values = data.split(",", 3);		
						people.add(j, new Person(values[0], values[1],values[2]));
						j++;
						values = null;
					}
					
					myCentral.Text.setText(people.get(0).getName());
					
					inputStream.close();
					
				}catch(FileNotFoundException e1) {
					e1.printStackTrace();
					
				}
				
			}
				
			
			break;
			
		case "Save records":			
				String[] Line = new String[people.size()];
				
				JFileChooser fc1 = new JFileChooser("C:\\Users\\Usuario\\Desktop\\");
				
				int returnVal1 = fc1.showSaveDialog(myMainWindow);
				
				if(returnVal1 == JFileChooser.APPROVE_OPTION) {
					try {
						String name = fc1.getSelectedFile().getAbsolutePath();
						if(!name.endsWith(".csv")) {
							name = name + ".csv";
							
						}
						
						FileWriter writer = new FileWriter(name, true);
						BufferedWriter bw = new BufferedWriter(writer);
						PrintWriter pw = new PrintWriter(bw);
						
						for(int i = 0; i < people.size(); i++) {
							Line[i] = people.get(i).getName() +","+ people.get(i).getAddress() +","+ people.get(i).getTlp();
						}

						for(int i = 0; i < Line.length; i++) pw.println(Line[i]);
						
						pw.flush();
						
						pw.close();
						
					}catch(IOException e2) {
						e2.printStackTrace();
						
					}
				}
				
				break;
		
		case "Add records":
			String s1 = myLeftBtns.getS();
			
			if(s1 == null) s1 = "Name";
				
			switch(s1) {
				case "Name":
					myCentral.Text.setText("<Name>");
					break;
					
				case "Address":
					myCentral.Text.setText("<Address>");
					break;
					
				case "Telephone":
					myCentral.Text.setText("<Telephone>");
					break;
					
			}
			
			people.add(new Person());
			myLeftBtns.Current++;
			
			break;
			
		case "Next record":
			if(myLeftBtns.Current < people.size()-1) { 
				myLeftBtns.Current++;
				String s11 = myLeftBtns.getS();
				
				if(s11 == null) s11 = "Name";
				
				switch (s11) {
				case "Name":
					myCentral.Text.setText(people.get(myLeftBtns.Current).getName());
					break;
					
				case "Address":
					myCentral.Text.setText(people.get(myLeftBtns.Current).getAddress());
					break;
					
				case "Telephone":
					myCentral.Text.setText(people.get(myLeftBtns.Current).getTlp());
					break;

				default:
					break;
				}
			}
			
			break;
			
		case "Previous records":
			String s11 = myLeftBtns.getS();
			
			if(s11 == null) s11 = "Name";
						
			if(myLeftBtns.Current != 0) {
				myLeftBtns.Current--;
				
				switch (s11) {
				case "Name":
					myCentral.Text.setText(people.get(myLeftBtns.Current).getName());
					break;
					
				case "Address":
					myCentral.Text.setText(people.get(myLeftBtns.Current).getAddress());
					break;
					
				case "Telephone":
					myCentral.Text.setText(people.get(myLeftBtns.Current).getTlp());
					break;
	
				}
			}
			
			break;
			
		case "Sort Record":
			Collections.sort(people, new Comparator<Person>() {
				@Override
				public int compare(Person p1, Person p2) {
					return p1.getName().compareTo(p2.getName());
					
				}
			});
			
			break;
		}

	}
	
}

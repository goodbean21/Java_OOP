package gui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class LeftBtns extends JPanel implements ActionListener{
	
	protected String s;
	protected JButton[] btn1 = new JButton[3];
	protected String[] btn1Name = {
			"Name", "Address", "Telephone" 
			};
	
	protected CentralPanel myCentral;
	protected DownBtns myDownBtns;
	protected int Current = 0;
	
	public void setMyDownBtns(DownBtns myDownBtns) {
		this.myDownBtns = myDownBtns;
	}

	public void setMyCentral(CentralPanel myCentral) {
		this.myCentral = myCentral;
	
	}
	
	public String getS() {
		return s;
		
	}

	public LeftBtns() {
		GridLayout g = new GridLayout(3, 1);
		setLayout(g);
		
		for(int i = 0 ; i<btn1.length; i++) {
			btn1[i] = new JButton(btn1Name[i]);
			btn1[i].addActionListener(this);
			add(btn1[i]);
			
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		s = e.getActionCommand();
		myCentral.Text.setText("");
		
		switch(s) {

		case "Name":
			if(!DownBtns.getPeople().isEmpty()) myCentral.Text.setText(DownBtns.getPeople().get(Current).getName());
				
			break;
			
		case "Address":
			if(!DownBtns.getPeople().isEmpty()) myCentral.Text.setText(DownBtns.getPeople().get(Current).getAddress());
			
			break;
			
		case "Telephone":
			if(!DownBtns.getPeople().isEmpty()) myCentral.Text.setText(DownBtns.getPeople().get(Current).getTlp());
			
			break;
		
		}
		
		
	}
	
}

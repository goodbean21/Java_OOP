package gui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class CentralPanel extends JPanel implements KeyListener{
	
	protected JTextArea Text;
	protected LeftBtns myleftBtns;
	protected DownBtns myDownBtns;
	
	public void setMyleftBtns(LeftBtns myleftBtns) {
		this.myleftBtns = myleftBtns;
		
	}

	public void setMyDownBtns(DownBtns myDownBtns) {
		this.myDownBtns = myDownBtns;
	}



	public CentralPanel() {
		Text = new JTextArea();
		GridLayout g = new GridLayout(1, 1);
		setLayout(g);
		
		add(Text);
		Text.addKeyListener(this);
		
		Text.setFont(new Font("Times New Roman", 22, 22));
		setAlignmentX(CENTER_ALIGNMENT);
		setAlignmentY(CENTER_ALIGNMENT);
		Text.setText("<Name>");
		Text.setEditable(true);
	
	}

	@Override
	public void keyPressed(KeyEvent e) {
		String s = myleftBtns.getS();
		
		if(s == null) s = "";
		
		switch (s) {
		case "Name":
			String currentName = myDownBtns.people.get(myleftBtns.Current).getName();
			if (Text.getText() != currentName) myDownBtns.people.get(myleftBtns.Current).setName(Text.getText());
			break;

		case "Address":
			String currentAddress = myDownBtns.people.get(myleftBtns.Current).getAddress();
			if (Text.getText() != currentAddress) myDownBtns.people.get(myleftBtns.Current).setAddress(Text.getText());
			
			break;
			
		case "Telephone":
			String currentTelephone = myDownBtns.people.get(myleftBtns.Current).getTlp();
			if (Text.getText() != currentTelephone) myDownBtns.people.get(myleftBtns.Current).setTlp(Text.getText());
			
			break;
			
			default:
				String currentName1 = myDownBtns.people.get(myleftBtns.Current).getName();
				if (Text.getText() != currentName1) myDownBtns.people.get(myleftBtns.Current).setName(Text.getText());
				break;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

}

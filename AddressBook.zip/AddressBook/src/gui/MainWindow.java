package gui;

import java.awt.BorderLayout;

import javax.swing.JFrame;

public class MainWindow extends JFrame {

	public MainWindow() {
		
		LeftBtns btn1 = new LeftBtns();
		DownBtns btn2 = new DownBtns();
		CentralPanel Text = new CentralPanel();
		
		btn1.setMyCentral(Text);
		btn1.setMyDownBtns(btn2);
		
		btn2.setMyCentral(Text);
		btn2.setMyMainWindow(this);
		btn2.setMyLeftBtns(btn1);
		
		Text.setMyleftBtns(btn1);
		Text.setMyDownBtns(btn2);
		
		BorderLayout b = new BorderLayout();
		setLayout(b);
		
		add(btn1, b.WEST);
		add(btn2, b.SOUTH);
		add(Text, b.CENTER);
		
		setSize(600, 600);
		setLocation(500, 200);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	}
	
}

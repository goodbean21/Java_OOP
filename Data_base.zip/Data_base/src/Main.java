import java.util.Objects;
import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {		
		// Variables
		Student[] student = new Student[10];
		
		String Choice, Name = null, last_Name = null, Grade, holdName = null, 
				holdLast_Name = null, Which = "", Ind = "", msg = null;
		
		int choice = 7, i = -1, grade = 0, p = 0, which = 0, 
				holdGrade = 0, Pos = 0, rest = -10;
		
		boolean exit = false, repeat = false, pass = true, notNull, bool_name = false, 
				bool_last_name = false, bool_grade = false;
		
		do {
			notNull = false;

			do {
				// Main menu
				Choice = JOptionPane.showInputDialog("Welcome press 1.To Add a student, 2. Edit an existing student, "
						+ "3. Find a student, 4. Delete a Student, "
						+ "5. Call roll, 6. Display all student names, "
						+ "7. to Exit");
				
				if(Choice != null){
					try {
						choice = Integer.parseInt(Choice);
						
						if(choice < 0){
							System.out.println("The entry have to be positive");
							repeat = true;
							
						}else {
							repeat = false;
						}
						
					}catch(Exception e) {
						System.out.println("The entry value have to be integer");
						repeat = true;
						
					}
				}
				
			}while(repeat); // Repeats until the entry is valid
				
			if(choice == 7 ) {
				// Exit program
				exit = true;
					
			}else if(choice == 1) {
				// Add a student
				Name = JOptionPane.showInputDialog("Name of the student");
				
				if(Name != null) { //If cancel is chosen it will stop
					last_Name = JOptionPane.showInputDialog("Last name of the student");
					
				}
				
				if(Name != null || last_Name != null) { // If either name or last name is cancel it won't continue
					do {
						Grade = JOptionPane.showInputDialog("Grade: ");
						
						if(Grade != null) {
							try {
								grade = Integer.parseInt(Grade);
								
								if(grade < 0) { // Checks for negative numbers
									System.out.println("The entry have to be positive");
									repeat = true;
									
								}else {
									repeat = false;
									pass = true;
									
								}
								
							}catch(Exception e) { // If then entry is non-numeric 
								System.out.println("The grade must be a real number");
								repeat = true;
								
							}
							
						}else {
							pass = false;
							
						}
						
					}while(repeat); // Repeats until the entry is valid
					
				}else {
					pass = false;
					
				}
				
				if(pass) { // Loops through the array
					i = -1;
					do {
						i++;
						repeat = true;
						if(i == 10) { // if the array is full it breaks the loop
							repeat = false;
							break;
						}
						
					}while(student[i] != null && repeat);
					
					if(i >= 10) {
						System.out.println(i+rest); //Change the nth position of the array, starting from 0
						student[i + rest] = new Student(Name, last_Name, grade);
						rest++; 
						
						if(rest == 0) {
							rest = -10;
							
						}
						
					}else {
						student[i] = new Student(Name, last_Name, grade); // Saves the attributes
					
					}
					
				}
				
			}else if(choice == 2) {
				// Editing a student
				for(int j = 0; j < 10; j++){ // Checks if there is at least 1 student
					if(student[j] != null) {
						notNull = true;
						p = j;
					}
					
				}
				
				if(!notNull) { // if no student had been added
					System.out.println("Please add a student");
				
				}else {
					do {
						// Ask for the number of the student on the list
						Ind = JOptionPane.showInputDialog("Who on the list you want to edit (Number)?"); 	
						
						if(Ind != null) {
							try {
								int ind = Integer.parseInt(Ind)-1;
								if(ind < 0 || ind > p) {
									System.out.println("The number have to be positive, and lesser or equal to " + (p + 1));
									repeat = true;
									
								}else {
									repeat = false;
									
									do {
										Which = JOptionPane.showInputDialog("To edit: 1. Name, 2. Last Name, 3. Grade, 7. Finish");
										try {
											// Entry validation
											which = Integer.parseInt(Which);
											
											if(which < 1 && which > 3 && which != 7) {
												System.out.println("Invalid entry");
												repeat = true;
											
											}else {
												// Holders for the original attributes of the class
												holdName = student[ind].getName();
												holdLast_Name = student[ind].getLast_Name();
												holdGrade = student[ind].getGrade();
												
											}
											if(which == 7) {
												// Exit
												repeat = false;
												
											}else if(which == 1) {
												// Changes the name if not cancel
												Name = JOptionPane.showInputDialog("Which is the student's name?");
												bool_name = true; // Existing new name
												repeat = true;
												
											}else if(which == 2) {
												// Changes the last name if not cancel
												last_Name = JOptionPane.showInputDialog("Which is the student's last name?");
												bool_last_name = true; // Existing new last name
												repeat = true;

											}else if(which == 3) {
												do {
													Grade = JOptionPane.showInputDialog("Which is the student's grade?");
													
													try {
														// Entry validation
														grade = Integer.parseInt(Grade);
														if(grade < 0) {
															System.out.println("The entry have to be a real positive number");
															repeat = true;
															
														}else {
															repeat = false;
															bool_grade = true; // Existing new grade
															
														}
														
													}catch(Exception e) {
														System.out.println("The entry have to be an integer");
														repeat = true;
														
													}
													
												}while(repeat);
												repeat = true; // Repeats until validation 
												
											}
											
											//If no existing new attribute the holder gets loaded
											if(!bool_name) {
												Name = holdName;
												
											}if(!bool_last_name) {
												last_Name = holdLast_Name;
												
											}if(!bool_grade) {
												grade = holdGrade;
												
											}
											
											// Edits the student 
											student[ind] = new Student(Name, last_Name, grade);											
											// student[ind].setName(Name);
											// student[ind].setLast_Name(last_Name);
											// student[ind].setGrade(grade);
											
										}catch(Exception e) {
											System.out.println("The value have to be an integer");
											repeat = true;
											
										}
										
									}while(repeat && Which != null); //Repeats until validation or cancel
								}
							
							}catch(Exception e) {
								System.out.println("The number have to an integer");
								repeat = true;
	
							}
						}
					}while(repeat && Ind != null); // Repeats until validation or cancel
					
				}
				p = 0;
				
			}else if(choice == 3) {
				// Looks for a student, cap sensitive
				
				notNull = false;
				for(int j = 0; j < 10; j++){
					if(student[j] != null) {
						notNull = true; // Verifies that at least 1 student exists

						p = j;
						
					}
					
				}
				if(!notNull) {
					System.out.println("Please add a student");
				
				}else {
					Name = JOptionPane.showInputDialog("The name of the student you're looking for:");						
					boolean found = false;
					
					for(int z = 0; z < 10; z++) {
						if(student[z] != null && Objects.equals(student[z].getName(),Name)) {
							found = true; // Looks for the student
							Pos = z;
							
						}
					}
					
					if(found) {
						// If found prints the name of the student and grade
						System.out.println(student[Pos].getName()+ "'s grade is " + student[Pos].getGrade());
					
					}else {
						System.out.println("This student doesn't exist");
						
					}
				}
				
			}else if(choice == 4) {
				// Erase a student
				notNull = false;
				for(int j = 0; j < 10; j++){
					if(student[j] != null) {
						notNull = true; // At least 1 student exists
						p = j;
					}
					
				}
				if(!notNull) {
					System.out.println("Please add a student");
				
				}else {
					do {	
						// Erases a student by their list number, starting from 1
						String P = JOptionPane.showInputDialog("Who on the list do you want to erase(starting from 1)");
						
						if(P != null) {
							try {
								int position = Integer.parseInt(P)-1;
								
								if(position < 0 || position > 9) {
									System.out.println("The entry have to be between 1 and 10");
									repeat = true;
									
								}else {
									if(student[position] == null) {
										System.out.println("This student is already blank");
										
									}else {
										for(int x = position; x < 10; x++) {
											// Changes student 2 to 1, 3 to 2, 4 to 3 ,etc...
											// Starting from the position of the student to erase
											try {
												student[x] = student[x+1];
												
											}catch(Exception e) {
												student[x] = null; // Makes the last student null
												
											}
											
										}
										repeat = false;
									}
									
								}
								
							}catch(Exception e){
								System.out.println("The entry have to be an integer");
								repeat = true;
								
							}
						}else {
							repeat = false;
							
						}
					}while(repeat); // Repeats until validation
				}
			}else if(choice == 5) {
				// Roll call
				notNull = false;
				for(int j = 0; j < 10; j++){
					if(student[j] != null) {
						notNull = true; // At least 1 student have to exists
						p = j;
					}
					
				}
				if(!notNull) {
					System.out.println("Please add a student");
				
				}else {
					for(i = 0; i < 10; i++) {
						if(student[i] != null) {
							// Yes or no question for attendance
							int in = JOptionPane.showConfirmDialog(null, "Is " + student[i].getName() + " here?");
	
							if(in == JOptionPane.YES_OPTION) {
								student[i].setAttendance(true);
								
							}else if(in == JOptionPane.NO_OPTION) {
								student[i].setAttendance(false);
							
							}else {
								break;
								
							}
						}
					}
				}
				
			}else if(choice == 6) {
				// Displays all students that exists
				notNull = false;
				for(int j = 0; j < 10; j++){
					if(student[j] != null) {
						notNull = true; // At least 1 student have to exists
						p = j;
						
					}
				}
				
				if(!notNull) {
					System.out.println("Please add a student");
				
				}else {
					for(i = 0; i < 10; i++){
						if(student[i] != null) {
							if(student[i].isAttendance()) {
								msg = "here";
								
							}else {
								msg = "not here";
								
							}
							System.out.println((i + 1)+". " +student[i].getName() + " " +student[i].getLast_Name() +
									" from "+ student[i].getGrade() + " is " + msg);
							
						}
					}
				}
			}
			
		}while(exit == false && Choice != Integer.toString(JOptionPane.CANCEL_OPTION));
	}
}

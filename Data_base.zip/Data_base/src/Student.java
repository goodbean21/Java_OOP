
public class Student {
	
	public String name;
	public String last_Name;
	public int grade;
	public boolean attendance;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
		
	}
	public String getLast_Name() {
		return last_Name;
		
	}
	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
		
	}
	public int getGrade() {
		return grade;
		
	}
	public void setGrade(int grade) {
		this.grade = grade;
		
	}
	public boolean isAttendance() {
		return attendance;
		
	}
	public void setAttendance(boolean attendance) {
		this.attendance = attendance;
		
	}
	
	public Student(String name, String last_Name, int grade) {
		this.name = name;
		this.last_Name = last_Name;
		this.grade = grade;
		
	}
	
	public Student() {
		this.name = null;
		this.last_Name = null;
		this.grade = 0;
		
	}
	
}

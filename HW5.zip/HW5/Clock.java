public class Clock{
	private int hr;
	private int min;
	private int sec;
	protected String message;

	public int getHr(){
		return hr;
	}

	public int getMin(){
		return min;
	}

	public int getSec(){
		return sec;
	}

	public void setTime(int hr, int min, int sec) throws WrongTimeException{
		this.hr = hr;
		this.min = min;
		this.sec = sec;

		if(hr < 0 || hr >= 24){
			message = "La hora solo puede estar entre 00 y 23";
			WrongTimeException wte = new WrongTimeException(message);
			throw wte;

		}

		if(min < 0 || min >= 60){
			message = "Los minutos solo pueden estar entre 00 y 59";
			WrongTimeException wte = new WrongTimeException (message);
			throw wte;

		}

		if(sec < 0 || sec >= 60){
			message = "Los segundos solo pueden estar entre 00 y 59";
			WrongTimeException wte = new WrongTimeException (message);
			throw wte;
		}
		// Create a WrongTimeException to be thrown if any value is wrong

	}

	public Clock(){
		// Initialize values
		this.hr = 0;
		this.min = 0;
		this.sec = 0;

	}

	public Clock(int hr, int min, int sec) throws WrongTimeException{
		//
		this.hr = hr;
		this.min = min;
		this.sec = sec;

		if(hr < 0 || hr >= 24){
			message = "La hora solo puede estar entre 00 y 23";
			WrongTimeException wte = new WrongTimeException(message);
			throw wte;

		}

		if(min < 0 || min >= 60){
			message = "Los minutos solo pueden estar entre 00 y 59";
			WrongTimeException wte = new WrongTimeException (message);
			throw wte;

		}

		if(sec < 0 || sec >= 60){
			message = "Los segundos solo pueden estar entre 00 y 59";
			WrongTimeException wte = new WrongTimeException (message);
			throw wte;

		}

	}

	public void printTime(){
		String Sec = Integer.toString(this.sec);
		String Min = Integer.toString(this.min);
		String Hr = Integer.toString(this.hr);
		String Time = "";

		if(sec < 10){
			Sec = '0'+ Sec;

		}
		if(min < 10){	
			Min = '0'+ Min;

		}
		if(hr < 10){
			Hr = '0' + Hr;
		}

		Time = Hr +":" + Min +":" + Sec;
		System.out.println(Time);
		// Print hours, mins, sec in a human readable form

	}

	public int incrementHours(){
		// Add plus one to hour
		// After 23 it becomes 0
		// Return new hour value
		if(this.hr < 23){
			this.hr = hr + 1;

		}else if(this.hr == 23){
			this.hr = 0;
		}

		return hr;

	}

	public int incrementMin(){
		// Add plus one to minutes
		// After 59  that means 60 add ones to hours (calling the incrementHours method)
		// Return min
		if(this.min < 59){
			this.min = min + 1;

		}else if(this.min == 59){
			this.min = 0;
			incrementHours();
		}
		return min;
	}

	public int incrementSec(){
		// Same as incrementMin
		// Return sec
		if(this.sec < 59){
			this.sec = sec + 1;
		}else if (this.sec == 59){
			incrementMin();
			sec = 0;
		}
		return sec;

	}

	public boolean equals(Clock theOther){
		// if hrs, mins, secs are the same}
		if(this.hr == theOther.hr){
			if(this.min == theOther.min){
				if(this.sec == theOther.sec){
					return true;

				}
			}
		}

		return false;
	}

	public void makeCopy(Clock theOther) throws WrongTimeException{
		// Set my clock values to theOther's values

		if(theOther.getHr() < 0 || theOther.getHr() >= 24){
			message = "La hora solo puede estar entre 00 y 23";
			WrongTimeException wte = new WrongTimeException(message);
			throw wte;

		}

		if(theOther.getMin() < 0 || theOther.getMin() >= 60){
			message = "Los minutos solo pueden estar entre 00 y 59";
			WrongTimeException wte = new WrongTimeException (message);
			throw wte;

		}

		if(theOther.getSec() < 0 || theOther.getSec() >= 60){
			message = "Los segundos solo pueden estar entre 00 y 59";
			WrongTimeException wte = new WrongTimeException (message);
			throw wte;
		}

		this.setTime(theOther.getHr(), theOther.getMin(), theOther.getSec());

	}

	public Clock getCopy(){
		// return theOther's copy 
		return this;
	}

}
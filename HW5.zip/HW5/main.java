import java.lang.*;
import javax.swing.*;

// Create a new Clock object
// simple menu to deal with it (A Loop)
// 1. Initialize the clock, ask the user for value
// 2. Set time, ask the user for values
// 3. Print Clock
// 4. Copy into clock - Create a new clock, asking new values
// 5. Copy from clock - Create a clone from a our clock and print it

// 6. End

public class main{

	public static void main(String[] args){
		boolean realTime = false, Equals = false, setClk = false, existingCopy = false, retry = false;
		int hr = 0, min = 0, sec = 0;
		String[] TimeAr = null;
		int choice = 0, choice2 = 0, choice3 = 0, choice4 = 0, choice5 = 0, choice6 = 0, lim = 0;
		String Time, message, Choice;
		Clock clk = new Clock();
		Clock copy = new Clock();
		Clock Clk = new Clock();

		// Set hour or default
		do{
			do{
				Choice = JOptionPane.showInputDialog("Welcome if you want to start press any number, else press 7 to quit at any moment");
				try{
					choice = Integer.parseInt(Choice);
					if(choice < 0){
						choice = -1;
						System.out.println("The value has to be positive");
					}

				}catch(Exception e){
					System.out.println("None numerical entry");
					choice = -1;

				}
			}while(choice < 0);

			choice4 = 2;

			if(choice != 7){
				do{
					Choice = JOptionPane.showInputDialog("Want to set the clock(1) or use the default(2)?");
					try{
						choice = Integer.parseInt(Choice);	

					}catch(Exception e){
						System.out.println("None numerical entry");
					}

					if(choice == 1){
						setClk = true;

					}else if(choice == 2){
						setClk = false;
						retry = false;

					}else if(choice == 7){
						System.exit(0);
					}
					if(choice != 2 && choice != 1 && choice != 7){
						System.out.println("The number has to be 1, 2 or 7");

					}

				}while(choice != 1 && choice != 2);

				do{ 
					//Give the value of hour, minutes, and seconds
					if(setClk){
						Time = JOptionPane.showInputDialog("What time is it?(Format hr:min:sec)");
						try{
							TimeAr = Time.split(":",3);	

							hr = Integer.parseInt(TimeAr[0]);
							min = Integer.parseInt(TimeAr[1]);
							sec = Integer.parseInt(TimeAr[2]);
							try{
								clk = new Clock(hr, min, sec);
								retry = false;

							}catch(WrongTimeException wte){
								System.out.println(wte);
								retry = true;
							}

						}catch(Exception e){
							System.out.println("Wrong time format. It needs to be hr:min:sec");
							retry = true;

						}
					}else{
						clk = new Clock();

					}

				}while(retry);

				if(retry == false){
					// Make it run with the real value of seconds or with the speed processing of the laptop
					do{
						Choice = JOptionPane.showInputDialog("If you want the second to last a second press(3) else press (4)");
						try{
							choice2 = Integer.parseInt(Choice);

						}catch(Exception e){
							System.out.println("None numerical entry. Please try again");
							choice2 = 1;

						}
						// System.out.println(choice2);

						if(choice2 == 3){
							realTime = true;

						}else if (choice2 == 4){
							realTime = false;

						}else if(choice2 == 7){
							System.exit(0);

						}
						if(choice2 != 2 && choice2 != 1 && choice2 != 7){
							System.out.println("The number has to be 3, 4 or 7");

						}

					}while(choice2 != 3 && choice2 != 4);

					if(setClk == true){

						do{
							Choice = JOptionPane.showInputDialog("Want to make a copy(1. Yes, 2. No)?");

							try{
								choice3 = Integer.parseInt(Choice);

							}catch(Exception e){
								System.out.println("None numerical entry. Please try again");
								choice3 = 3;

							}
				
							if(choice3 == 1){
								try{
									Clk.makeCopy(clk);
									existingCopy = true;

								}catch(WrongTimeException wte){
									System.out.println(wte);

								}
								do{
									Choice = JOptionPane.showInputDialog("Want to check the copy(1. Yes, 2. No)?");
									try{
										choice4 = Integer.parseInt(Choice);

									}catch(Exception e){
										choice4 = 3;
										System.out.println("None numerical entry. Please try again");

									}
									if(choice4 == 1){
										copy = Clk.getCopy();
										copy.printTime();

									}else if(choice4 == 7){
										System.exit(0);
									}
									if(choice4 != 2 && choice4 != 1 && choice4 != 7){
										System.out.println("The number has to be 1, 2 or 7");
									}

								}while(choice4 != 2 && choice4 != 1);

							}else if(choice3 == 7){
								System.exit(0);
							}
							if(choice3 != 2 && choice3 != 1 && choice3 != 7){
								System.out.println("The number has to be 1, 2 or 7");

							}

						}while(choice3 != 2 && choice3 != 1);

					}

					if(existingCopy && choice4 == 2){
						do{
							Choice = JOptionPane.showInputDialog("You have a copy want to check it(1. Yes, 2. No)?");
							try{
								choice5 = Integer.parseInt(Choice);
							
							}catch(Exception e){
								choice5 = 3;
								System.out.println("None numerical entry. Please try again");

							}

							if(choice5 == 1){
								copy = Clk.getCopy();
								copy.printTime();

							}else if(choice5 == 7){
								System.exit(0);
							}
							if(choice5 != 2 && choice5 != 1 && choice5 != 7){
								System.out.println("The number has to be 1, 2 or 7");
							}

						}while(choice5 != 1 && choice5 != 2);
					}

					if(existingCopy){
						do{
							Choice = JOptionPane.showInputDialog("Want to check if your clock is the same as the saved?(1. Yes, 2. No)");
							try{
								choice6= Integer.parseInt(Choice);

							}catch(Exception e){
								choice6 = 3;
								System.out.println("None numerical entry. Please try again");

							}

							if(choice6 == 1){
								Equals = copy.equals(clk);
								if(Equals){
									System.out.println("They are the same");
								}else{
									System.out.println("Not equal");
								}
							}else if(choice6 == 7){
								System.exit(0);
							}
							if(choice6 != 2 && choice6 != 1 && choice6 != 7){
								System.out.println("The number has to be 1, 2 or 7");

							}

						}while(choice6 != 1 && choice6 != 2);
					}

					do{
						Choice = JOptionPane.showInputDialog("How many seconds you want to code to run?(Must be integer positive)");
						try{
							lim= Integer.parseInt(Choice);
							if(lim < 0){
								lim = -1;
								System.out.println("The given value is negative. Please try again");

							}

						}catch(Exception e){
							lim = -1;
							System.out.println("None numerical entry. Please try again");

						}
					}while(lim == -1);

					for(int i = 0; i <= lim; i++){

						//Printing and incrementing time
						clk.printTime();
						clk.incrementSec();

						if(realTime){
							try{
							Thread.sleep(1000);

							}catch(Exception e){
								System.out.println(e);

							}


						}
					}
				}
			}
		}while(choice != 7);
	}
}
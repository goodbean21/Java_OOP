public class WrongTimeException extends Exception{
	protected String message;

	public WrongTimeException(String message){
		super(message);

	}
}
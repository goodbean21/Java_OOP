package gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.*;

public class MainWindow extends JFrame{
	JTextArea area;
	JMenuBar bar;
	JMenu file, menu; 
	JMenuItem load, save;
	BorderLayout B;
	
	public MainWindow() {
		
		super("Text Editor");
		
		B = new BorderLayout();
		setLayout(B);
		
		area = new JTextArea();
		area.setLineWrap(true);
		
		bar = new JMenuBar();
		file = new JMenu("File");
		load = new JMenuItem("Load");
		save = new JMenuItem("Save");
		
		load.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser();
				int returnVal = fc.showOpenDialog(MainWindow.this);		
				
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					area.setText("");
					FileReader f;
					BufferedReader br = null;
					
					try {
						f = new FileReader(fc.getSelectedFile());
						br = new BufferedReader(f);
						String line = "";
						while((line = br.readLine()) != null) area.setText(line);		
						br.close();
						
					}catch(FileNotFoundException e1) {
						e1.printStackTrace();
						
					}catch(IOException e1) {
						e1.printStackTrace();
						
					}
					
				}
			}
		});
		
		save.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser();
				int returnval =	fc.showSaveDialog(MainWindow.this);
				
				if(returnval == JFileChooser.APPROVE_OPTION) {
					try {
						String name = fc.getSelectedFile().getAbsolutePath();
						if(!name.endsWith(".txt")) {
							name = name + ".txt";
							
						}
						
						FileWriter writer = new FileWriter(name);
						BufferedWriter bw = new BufferedWriter(writer);
						
						bw.write(area.getText());
						
						bw.close();
						
					}catch(IOException e2) {
						e2.printStackTrace();
						
						
					}
				}
			}
		});
		
		file.add(save);
		file.add(load);
		
		bar.add(file);
		setJMenuBar(bar);
		
		add(area, BorderLayout.CENTER);
		
		setSize(600, 600);
		setLocation(500, 500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

}
